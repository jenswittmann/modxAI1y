## modxAI1y

modxAI1y helps you with some AI magic to generate simple image captions in ContentBlocks.