## modxAI1y 0.1.0

Released on 2025-01-05

- initial release